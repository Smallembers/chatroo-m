A chatroom for school that me and my freinds mess around in 
Will be adding file uploads and gifs maybe
